<? php

$servername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "IT490Project";

$conn = mysqli_connect($servername, $dbUsername, $dbPassword, $dbName);

if (!$conn) {
	die("Connection Failed:" . mysqli_connect_error());

}

















?>

