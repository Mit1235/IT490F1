function openForm() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
} 

function checkLoginCredentials(){
    
    var loginUsernameNotClean = document.getElementById('username_login').value;
    var loginPasswordNotClean = document.getElementById('password_login').value;
    

    