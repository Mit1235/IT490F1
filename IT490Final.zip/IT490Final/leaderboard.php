<html>
    <head>
        <title>LeaderBoard Using PHP</title>
    </head>
  
    <body>
        <h2>Welcome To GFG</h2>
        <table>
            <tr>
                <td>Ranking</td>
                <td>UserName</td>
                <td>Marks</td>
            </tr>
    <
